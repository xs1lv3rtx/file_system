/*
 * Author(s): <Juan Sanchez>
 * COS 318, Fall 2015: Project 6 File System.
 * Implementation of a Unix-like file system.
*/
#include "util.h"
#include "common.h"
#include "block.h"
#include "fs.h"

#ifdef FAKE
#include <stdio.h>
#define ERROR_MSG(m) printf m;
#else
#define ERROR_MSG(m)
#endif

#define MAX_FILES 256
#define MAGIC_NUMBER 31232142

FILE* fd_table[MAX_FILES];

superblock s;

unsigned char * free_inodes;

unsigned char * free_blocks;

int root_dir;

int working_dir;

int cur_open_file;

void init_fd_table(void) {
  int i;
  for (i = 0; i < MAX_FILES; i++) {
    fd_table[i] = NULL;
  }
}

void init_free_inodes(int size) {
  unsigned char inodes[size];
  int i;
  for (i = 0; i < size; i++) {
    inodes[i] = 0;
  }
  bcopy(inodes, free_inodes, size);
}

void init_free_blocks(int size) {
  unsigned char blocks[size];
  int i;
  for (i = 0; i < size; i++) {
    blocks[i] = 0;
  }
  bcopy(blocks, free_blocks, size);
}

int get_free_fd() {
  int i;
  for (i = 0; i < MAX_FILES; i++) {
    if (fd_table[i] == NULL) {
      return i;
    }
  }
  return -1;
}

int get_free_inode() {
  int i;
  for (i = 0; i < s.num_inodes; i++) {
    if (free_inodes[i] == 0) {
      free_inodes[i] = 1;
      return i;
    }
  }
  return -1;
}

int get_free_block() {
  int i;
  for (i = 0; i < s.num_blocks; i++) {
    if (free_blocks[i] == 0) {
      free_blocks[i] = 1;
      return i;
    }
  }
  return -1;
}

directory init_dir (directory dir, int current, int parent) {
  dir_t entries[BLOCK_SIZE/sizeof(dir_t)];
  dir_t cur;
  dir_t par;
  char *dot = ".";
  char *dot_dot = "..";

  cur.inode_num = current;
  par.inode_num = parent;
  
  bcopy((unsigned char *) dot, (unsigned char *) cur.name, 1);
  bcopy((unsigned char *) dot_dot, (unsigned char*) par.name, 2);

  entries[0] = cur;
  entries[1] = par;
  dir.entries = entries;
  return dir;
}

i_node init_dir_node (i_node node, int num) {
  directory dir;
  int free_block;
  int i;
  char *mem;
  node.inode_num = num;
  node.inode_parent = num;
  node.type = DIRECTORY;
  node.mode = FS_O_RDONLY;
  node.links = 0;

  dir = init_dir(dir, num, num);
  free_block = get_free_block();

  memcpy(mem, &dir, sizeof(dir));
  
  block_write(s.data_block_start + free_block, mem);

  node.block[0] = free_block;

  for (i = 1; i < 8; i++) {
    node.block[i] = -1;
  }

  node.pointer_block = -1;

  node.size = 2 * sizeof(dir_t);
  node.blocks = 1;
  return node;
}

i_node init_inode (i_node node, int num, int type, int flags) {
  int i;
  node.inode_num = num;
  node.type = type;
  node.mode = flags;
  node.links = 0;
  node.size = 0;
  node.blocks = 0;
  
  for (i = 0; i < 8; i++) {
    node.block[i] = -1;
  }
  node.pointer_block = -1;
  return node;
}

int is_present(directory dir, char * filename, int size) {
  int i;
  dir_t entry;
  for (i = 0; i < size; i++) {
    entry = dir.entries[i];
    if (same_string(filename, entry.name)) {
      return i;
    }
  }
  return 0;
}
void 
fs_init( void) {
    block_init();
    // initialize file system?
    // initialize inodes
    //
}

int
fs_mkfs( void) {
  superblock s;
  int num_data_blocks = ((FS_SIZE - 1) * BLOCK_SIZE)/((sizeof(i_node) + 2 + BLOCK_SIZE));
  i_node node;
  char * mem;
  
  fs_init();
  
  //Write superblock
  s.size = FS_SIZE;
  s.num_inodes = num_data_blocks;
  s.num_blocks = num_data_blocks;
  s.inode_start = 1;
  s.inode_map_start = s.inode_start + (int)((s.num_inodes)/ (BLOCK_SIZE/sizeof(i_node)));
  s.block_map_start = s.inode_map_start + (int)((s.num_inodes)/ (BLOCK_SIZE));
  s.data_block_start = FS_SIZE - s.num_blocks;
  s.magic_number = MAGIC_NUMBER;
  
  memcpy(mem, &s, sizeof(s));
  
  block_write(0, mem);
  
  // Initialize free_inodes and free_blocks map
  init_free_inodes(s.num_inodes);
  init_free_blocks(s.num_blocks);

  //Create root directory
  node = init_dir_node(node, get_free_inode());

  root_dir = node.inode_num;
  working_dir = node.inode_num;

  memcpy(mem, &node, sizeof(node));
  
  block_write(s.inode_start, mem);

  block_write(s.inode_map_start, (char *)free_inodes);
  block_write(s.block_map_start, (char *)free_blocks);
  

  init_fd_table();
  return -1;
}

int 
fs_open( char *fileName, int flags) {
  directory dir;
  int node_per_block = BLOCK_SIZE/sizeof(i_node);
  i_node block_nodes[node_per_block];
  i_node node;
  char * mem;
  int block = s.inode_start + (int)(working_dir/ node_per_block);
  FILE *fd;
  int i;
  int size;

  block_read(block, mem);
  memcpy(block_nodes, mem, sizeof(mem));
  node = block_nodes[working_dir % node_per_block];
  
  block_read(s.data_block_start + node.block[0], mem);
  memcpy(&dir, mem, sizeof(mem));

  i = is_present(dir, filename, (int)(node.size/sizeof(dir_t)));
  if (i != -1) {
    block_read(s.inode_start + (int) (dir.entries[i].inode_num/node_per_block), mem);
    memcpy(block_nodes, mem, sizeof(mem));
    node = block_nodes[dir.entries[i].inode_num % node_per_block];
    fd = fd_table[get_free_fd];
    switch (flags) {
    case FS_O_RDONLY:
      fd = fopen(filename, "r");
      break;
    case FS_O_WRONLY:
      fd = fopen(filename, "w");
      break;
    case FS_O_RDWR:
      fd = fopen(filename, "w+");
      break;
    }
    for (i = 0; i < node.blocks; i++) {
      block_read(node.block[i] + s.data_block_start, mem);
      
    }
  }
  return -1;
}

int 
fs_close( int fd) {
  FILE *f = fd_table[fd];
  int ret;
  ret = fclose(f);
  if (ret == FALSE) return -1;
  return 0;
   
}

int 
fs_read( int fd, char *buf, int count) {
  FILE *f = fd_table[fd];
  int ret;
  if (f == NULL) {
    return -1;
  }
  if (count == 0) {
    return 0;
  }
  ret = fread(buf, sizeof(char), count, f);
  if (ret <= count) {
    return 0;
  }
  return -1;
}
    
int 
fs_write( int fd, char *buf, int count) {
  FILE *f = fd_table[fd];
  int ret;
  if (f == NULL) {
    return -1;
  }
  int ret = fwrite(f, buf, count);
  if (!ret) {
    return -1;
  }
  if (ret == 0 && count > 0) {
    return -1;
  }
  if (ret <= count) {
    return 0;
  }
  return -1;
}

int 
fs_lseek( int fd, int offset) {
  FILE *f = fd_table[fd];
  int ret;
  int i;
  int padding;
  if (f == NULL) {
    return -1;
  }
  if (SEEK_CUR + offset > SEEK_END) {
    padding = SEEK_CUR + offset - SEEK_END;
    ret = fseek(f, SEEK_END - SEEK_CUR, SEEK_CUR);
    if (ret == 0) {
      for (i = 0; i < padding; i++) {
	fs_write(f, "\0", sizeof("\0"));
      }
      ret = fseek(f, padding, SEEK_CUR);
      if (ret == 0) {
	return SEEK_CUR;
      }
    }
    else {
      return -1;
    }
  }
  ret = fseek(f, offset, SEEK_CUR);
  if (ret == 0) {
    return SEEK_CUR;
  }
  return -1;
}

int 
fs_mkdir( char *fileName) {
    return -1;
}

int 
fs_rmdir( char *fileName) {
    return -1;
}

int 
fs_cd( char *dirName) {
    return -1;
}

int 
fs_link( char *old_fileName, char *new_fileName) {
    return -1;
}

int 
fs_unlink( char *fileName) {
    return -1;
}

int 
fs_stat( char *fileName, fileStat *buf) {
    return -1;
}

